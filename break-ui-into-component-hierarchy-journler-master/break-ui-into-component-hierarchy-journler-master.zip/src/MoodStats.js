import React from 'react';

class MoodStats extends React.Component{

    /* Write code to return a React element that displays each mood smileys with its count
    as shown in the mock image*/
   
}

export default MoodStats;