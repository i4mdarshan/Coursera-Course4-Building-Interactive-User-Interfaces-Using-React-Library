import React from 'react';

class JournalEditor extends React.Component{
    /*Write code to return a React element that provides input elements to take 
    mood, title and writeup from the user.*/

    // Save and Cancel buttons should be available to perform save and cancel operations
    
}

export default JournalEditor;