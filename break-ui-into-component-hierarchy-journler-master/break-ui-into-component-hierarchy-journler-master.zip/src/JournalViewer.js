import React from 'react';

class JournalViewer extends React.Component{
    /* Write the code to return a React element that displays all the journal entries 
    in the format as shown in the mock image.*/


    //Edit and Delete buttons should be available to perform edit and delete functionality 
   
}

export default JournalViewer;