import React from 'react';

class JournalCollection extends React.Component{
  /*Write code to return the React element which has the collection of Journal entries
  in the format as shown in the mock image*/
}

export default JournalCollection;